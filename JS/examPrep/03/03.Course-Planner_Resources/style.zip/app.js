const baseUrl = "http://localhost:3030/jsonstore/tasks/";

const courseTypes = ["Long", "Medium", "Short"];

// INPUTS
const titleInput = document.querySelector("#course-name");
const typeInput = document.querySelector("#course-type");
const descriptionInput = document.querySelector("#description");
const teacherInput = document.querySelector("#teacher-name");

// FIELDS
const courseList = document.querySelector("#list");

// LOAD BUTTON
const loadButtonElement = document.querySelector("#load-course");
loadButtonElement.addEventListener("click", loadCourses);

// EDIT COURSE BUTTON
const editButtonElement = document.querySelector("#edit-course");
editButtonElement.addEventListener("click", editCourse)

//ADD COURSE BUTTON
const addButtonElement = document.querySelector("#add-course");
addButtonElement.addEventListener("click", addCourse);
// ID
let currentCourseId = ""

async function loadCourses() {
    courseList.innerHTML = "";
    const response = await fetch(baseUrl);
    const data = await response.json();
    const courses = Object.values(data);


    for (const course of courses) {
        const courseElement = renderCourse(course);
        // IMPORTANT
        courseElement.setAttribute("data-id", course._id);
        courseList.appendChild(courseElement);
    }
    deactivateBtn(editButtonElement);
}

function renderCourse(course) {
    const container = document.createElement("div");
    container.classList.add("container");

    const title = document.createElement("h2");
    title.textContent = course.title;

    const teacher = document.createElement("h3");
    teacher.textContent = course.teacher;

    const type = document.createElement("h3");
    type.textContent = course.type;

    const description = document.createElement("h4");
    description.textContent = course.description;

    const formEditBtn = document.createElement("button")
    formEditBtn.classList.add("edit-btn");
    formEditBtn.textContent = " Edit Course";
    formEditBtn.addEventListener("click", async (ev) => {
        titleInput.value = course.title;
        typeInput.value = course.type;
        descriptionInput.value = course.description;
        teacherInput.value = course.teacher;
        // IMPORTANT
        currentCourseId = container.getAttribute("data-id");

        deactivateBtn(addButtonElement);
        activateBtn(editButtonElement);
        courseList.removeChild(container);
    })

    const formFinishBtn = document.createElement("button")
    formFinishBtn.classList.add("finish-btn")
    formFinishBtn.textContent = "Finish Course"
    formFinishBtn.addEventListener("click", async () => {
        const id = course._id;
        await fetch(`${baseUrl}${id}`, {
            method: "DELETE"
        })
        await loadCourses()
    })

    container.appendChild(title);
    container.appendChild(teacher);
    container.appendChild(type);
    container.appendChild(description);
    container.appendChild(formEditBtn);
    container.appendChild(formFinishBtn);

    return container;
}

async function addCourse(e) {
    e.preventDefault();
    const currentType = typeInput.value;
    const findType = courseTypes.find((c) => c === currentType);
    if (!validInput() && !findType) {
        return;
    }
    const newCourseBody = {
        title: titleInput.value,
        type: typeInput.value,
        description: descriptionInput.value,
        teacher: teacherInput.value
    }
    await fetch(baseUrl, {
        method: "POST",
        body: JSON.stringify(newCourseBody)
    })
    cleanInput()
    await loadCourses();


}

async function editCourse(eve) {
    eve.preventDefault();

    if (!validInput() && !findType) {
        return;
    }

    const editedCourseBody = {
        title: titleInput.value,
        type: typeInput.value,
        description: descriptionInput.value,
        teacher: teacherInput.value
    }

    await fetch(`${baseUrl}${currentCourseId}`, {
        method: "PUT",
        headers: {
            "Content-type": "application/json"
        },
        body: JSON.stringify({
            title: titleInput.value,
            type: typeInput.value,
            description: descriptionInput.value,
            teacher: teacherInput.value
        })
    })
    deactivateBtn(editButtonElement);
    activateBtn(addButtonElement);
    cleanInput();
    await loadCourses()
}

function deactivateBtn(btn) {
    btn.disabled = "true";
}

function activateBtn(btn) {
    btn.disabled = "";
}

function validInput() {
    return titleInput.value !== "" && typeInput.value !== "" && descriptionInput.value !== "" && teacherInput.value !== "";
}

function cleanInput() {
    titleInput.value = ""
    typeInput.value = ""
    descriptionInput.value = ""
    teacherInput.value = ""

}