const baseUrl = "http://localhost:3030/jsonstore/tasks/"


//INPUTS
const nameInput = document.querySelector("#name")
const numDaysInput = document.querySelector("#num-days")
const fromDateInput = document.querySelector("#from-date")

// FORM
const formElement = document.querySelector("#form form");

// FIELDS
const vacationList = document.querySelector("#list");

// BUTTONS
const loadVacationsBtn = document.querySelector("#load-vacations");
const formAddBtn = document.querySelector("#add-vacation");
const formEditBtn = document.querySelector("#edit-vacation");

// EVENT LISTENERS
loadVacationsBtn.addEventListener("click", loadVacations);

formAddBtn.addEventListener("click", (ev) => {
    ev.preventDefault();
    if (nameInput.value !== "" &&
        numDaysInput.value !== "" &&
        fromDateInput.value !== "") {
        const newVacation = {
            name: nameInput.value,
            days: numDaysInput.value,
            date: fromDateInput.value,
        }
        fetch(baseUrl, {
            method: "POST",
            headers: {
                "Content-type": "application/json"
            },
            body: JSON.stringify(newVacation)
        })
            .then(loadVacations)

        clearForm();
    }
})

function loadVacations() {
    return fetch(baseUrl)
        .then(res => res.json())
        .then((result) => {
            renderVacations(Object.values(result));
        })
}


function renderVacations(vacations) {
    vacationList.innerHTML = "";
    vacations.forEach(vac => vacationList.appendChild(renderVacation(vac)));
}

function renderVacation(vacation) {
    const container = document.createElement("div");
    container.classList.add("container");

    const h2Element = document.createElement("h2");
    h2Element.textContent = vacation.name;

    const h3DateElement = document.createElement("h3");
    h3DateElement.textContent = vacation.date;

    const h3NumDaysElement = document.createElement("h3");
    h3NumDaysElement.textContent = vacation.days;

    const changeBtn = document.createElement("button")
    changeBtn.classList.add("change-btn");
    changeBtn.textContent = "Change";
    changeBtn.addEventListener("click", () => {
        nameInput.value = vacation.name;
        numDaysInput.value = vacation.days;
        fromDateInput.value = vacation.date;

        vacationList.removeChild(container);
        deactivateBtn(formAddBtn);
        activateBtn(formEditBtn);

        formElement.dataset.vacation = vacation._id;
    })

    const doneBtn = document.createElement("button")
    doneBtn.classList.add("done-btn");
    doneBtn.textContent = "Done";
    doneBtn.addEventListener("click", () => {
        fetch(`${baseUrl}${vacation._id}`, {
            method: "DELETE"
        }).then(loadVacations).then(() => {
            vacationList.removeChild(container);

        })
    })

    container.appendChild(h2Element);
    container.appendChild(h3DateElement);
    container.appendChild(h3NumDaysElement);
    container.appendChild(changeBtn);
    container.appendChild(doneBtn);

    return container;
}

formEditBtn.addEventListener("click", (e) => {
    e.preventDefault();
    const vacationId = formElement.dataset.vacation;
    const vacation = {
        name: nameInput.value,
        days: numDaysInput.value,
        date: fromDateInput.value,
        "_id": vacationId,
    }

    fetch(`${baseUrl}${vacationId}`, {
        method: "PUT",
        headers: {
            "Content-type": "application/json"
        },
        body: JSON.stringify(vacation)
    }).then(loadVacations).then(() => {
        deactivateBtn(formEditBtn);
        activateBtn(formAddBtn);
        clearForm();
    })

    delete formElement.dataset.vacation;
})


function validInput() {
    return nameInput.value !== "" &&
        numDaysInput.value !== "" &&
        fromDateInput.value !== ""
}

function clearForm() {
    nameInput.value = ""
    numDaysInput.value = ""
    fromDateInput.value = ""
}

function activateBtn(btn) {
    btn.disabled = "";
}

function deactivateBtn(btn) {
    btn.disabled = "true";
}