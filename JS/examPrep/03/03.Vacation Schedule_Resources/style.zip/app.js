const baseUrl = "http://localhost:3030/jsonstore/tasks/";
//INPUTS
const nameInput = document.querySelector("#name");
const numberOfDaysInput = document.querySelector("#num-days");
const fromDateInput = document.querySelector("#from-date");

// BUTTONS
const loadVacationsBtn = document.querySelector("#load-vacations");
loadVacationsBtn.addEventListener("click", loadVacations);

const addVacationBtn = document.querySelector("#add-vacation");
addVacationBtn.addEventListener("click", addVacation)


const editVacationBtn = document.querySelector("#edit-vacation");

//FIELDS
const confirmedVacationsList = document.querySelector("#list");


function getIdByName(personName) {
    return fetch(baseUrl)
        .then(res => res.json())
        .then(res => Object.entries(res).find((e) => e[1].name === personName)[1]._id)
}

async function loadVacations() {
    clearOldVacations();
    try {
        const vacations = await (await fetch(baseUrl)).json();
        Object.values(vacations).forEach(v => {
            const div = document.createElement("div");
            div.classList.add("container");

            const nameHeader = document.createElement("h2");
            nameHeader.textContent = v.name;

            const dateHeader = document.createElement("h3");
            dateHeader.textContent = v.date;

            const daysHeader = document.createElement("h3");
            daysHeader.textContent = v.days;

            const changeBtn = document.createElement("button");
            changeBtn.classList.add("change-btn");
            changeBtn.textContent = "Change";
            changeBtn.addEventListener("click", changeVacation);

            const doneBtn = document.createElement("button");
            doneBtn.classList.add("done-btn");
            doneBtn.textContent = "Done";
            doneBtn.addEventListener("click", doneVacation);

            div.appendChild(nameHeader);
            div.appendChild(dateHeader);
            div.appendChild(daysHeader);
            div.appendChild(changeBtn);
            div.appendChild(doneBtn);

            confirmedVacationsList.appendChild(div);


        })

    } catch (e) {
        console.log(e)
    }

    function changeVacation(event) {
        event.preventDefault();
        addVacationBtn.disabled = "true";
        editVacationBtn.disabled = "";
        const target = event.currentTarget.parentNode;
        const [name, date, days] = Array.from(target.children);
        nameInput.value = name.textContent;
        numberOfDaysInput.value = days.textContent;
        fromDateInput.value = date.textContent;

        editVacation(name.textContent)
        function editVacation(personName) {
            confirmedVacationsList.removeChild(target)
            editVacationBtn.addEventListener("click", finalEditVacation);

        }

    }



    function finalEditVacation(event) {
        event.preventDefault()
        const data = {
            name: nameInput.value,
            days: numberOfDaysInput.value,
            date: fromDateInput.value
        };
        getIdByName(data.name)
            .then((id) => fetch(`${baseUrl}${id}`, {
                    method: "PUT",
                    headers: {
                        "Content-type": "application/json"
                    },
                body: JSON.stringify({
                    name: data.name,
                    days: data.days,
                    date: data.date,
                    _id: id,
                })
                }
            )).then(clearInput).then(loadVacations);
        addVacationBtn.disabled = "";
        editVacationBtn.disabled = "true";
    }

    function doneVacation(event) {
        const target = event.currentTarget.parentNode;
        const personName = Array.from(target.children)[0];
        console.log(personName)
        console.log(target)
        confirmedVacationsList.removeChild(target);

        getIdByName(personName.textContent)
            .then((id) => fetch(`${baseUrl}${id}`, {
                method: "DELETE",
                headers: {
                    "content-type": "application/json"
                }
            })).then(loadVacations);

    }

}

function addVacation(event) {
    clearOldVacations();
    event.preventDefault();

    if (validInput()) {
        const headers = {
            method: "POST",
            body: JSON.stringify({
                name: nameInput.value,
                days: numberOfDaysInput.value,
                date: fromDateInput.value
            })
        }
        fetch(baseUrl, headers)
            .then(loadVacations)
            .catch(console.error);

        clearInput();
    }
}

function clearInput() {
    nameInput.value = "";
    numberOfDaysInput.value = "";
    fromDateInput.value = "";

}

function validInput() {
    return nameInput.value !== "" &&
        numberOfDaysInput.value !== "" &&
        fromDateInput.value !== "";

}

function clearOldVacations() {
    confirmedVacationsList.innerHTML = "";
}
